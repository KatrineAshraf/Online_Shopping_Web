// framework to create server
// includes app.get(), app.post(), app.put(), and app.delete() methods
const express = require("express");
// middleware used to extract the data sent in the request body
// basically allows us to access the JSON data sent in a POST or PUT request
const bodyParser = require("body-parser");
// middleware used to allow the server to receive requests from other domains.
const cors = require("cors");
const mongoose = require("mongoose");
const uri = "mongodb+srv://Bonus:1234@cluster0.iurfzp4.mongodb.net/?retryWrites=true&w=majority";
const app = express();
const port = 3000;
const options = {
    useNewUrlParser: true,
    useUnifiedTopology: true
};
const customerRoute = require("./routes/customerRoute")
const productRoute = require("./routes/productRoute")

app.use(bodyParser.json());
app.use(cors());

app.use(productRoute);
app.use(customerRoute);

mongoose.set("strictQuery", false);
mongoose.connect(uri, options).then(() => {
    app.listen(port, () => console.log("Server started at http://localhost:" + port));
}).catch((err) => {
    console.log(err);
});
